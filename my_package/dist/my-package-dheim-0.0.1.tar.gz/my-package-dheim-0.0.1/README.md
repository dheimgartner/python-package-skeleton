# Example Package

This is my first example package. After having setup the setup file, I now write these lines.
They will be leveraged in the `long_description` within the `setup()` call in `setup.py`.

This is just a simple markdown ...
You can use [Github-flavored Markdown] (https://guides.github.com/features/mastering-markdown/) to write your content.

Now, I'll create the LICENCE for this awesome package!